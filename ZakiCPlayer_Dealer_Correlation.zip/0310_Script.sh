#!/bin/sh
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep $1

echo On  March 10 these rouletee dealer was working.
