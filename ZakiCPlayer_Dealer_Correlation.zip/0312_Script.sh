#!/bin/sh
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep $1
echo On March 12, these Rouletee dealers were working.
