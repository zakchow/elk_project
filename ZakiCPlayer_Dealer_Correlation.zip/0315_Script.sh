#!/bin/sh

awk '{print $1, $2, $5, $6}' 0315_Dealer_schedule | grep $1
echo On March 15th, these Roulette Dealers were working.
